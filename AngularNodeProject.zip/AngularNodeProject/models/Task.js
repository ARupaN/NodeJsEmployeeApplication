var db=require('../dbconnection');

var Employee={

getAllTasks:function(callback){

return db.query("Select * from employee",callback);

},
getTaskById:function(id,callback){

    return db.query("select * from employee where Id=?",[id],callback);
},
getLatestRecord:function(callback){
	return db.query("select * from employeedb.employee order by id desc limit 1",callback);
},
addTask:function(Employee,callback){
   console.log("inside service");
   console.log(Employee.Id);
return db.query("Insert into employee values(?,?,?,?,?,?)",[Employee.Id,Employee.firstname,Employee.lastname,Employee.address,Employee.company,Employee.salary],callback);
//return db.query("insert into employee(Id,Title,Status) values(?,?,?)",[Task1.Id,Task1.Title,Task1.Status],callback);
},
deleteTask:function(id,callback){
    return db.query("delete from employee where Id=?",[id],callback);
},
updateTask:function(id,Employee,callback){
    return  db.query("update employee set Title=?,Status=? where Id=?",[Employee.Title,Employee.Status,id],callback);
},
deleteAll:function(item,callback){

var delarr=[];
   for(i=0;i<item.length;i++){

       delarr[i]=item[i].Id;
   }
   return db.query("delete from employee where Id in (?)",[delarr],callback);
}
};
module.exports=Employee;