
--
CREATE SCHEMA `employeedb` ;




CREATE TABLE IF NOT EXISTS `employeedb`.`employee` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `firstname` VARCHAR(45) NULL,
  `lastname` VARCHAR(45) NULL,
  `address` VARCHAR(45) NULL,
  `company` VARCHAR(45) NULL,
  `salary` VARCHAR(45) NULL,
  PRIMARY KEY (`id`));
  
INSERT INTO `employeedb`.`employee` (`id`, `firstname`, `lastname`, `address`, `company`, `salary`) VALUES ('1', 'Rupa', 'Naidu', 'US', 'IBM', '999999');



